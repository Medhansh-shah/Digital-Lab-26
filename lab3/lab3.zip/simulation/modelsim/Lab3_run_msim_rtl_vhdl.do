transcript on
if {[file exists rtl_work]} {
	vdel -lib rtl_work -all
}
vlib rtl_work
vmap work rtl_work

vcom -93 -work work {D:/DigitalLab26/lab3/Gates.vhd}
vcom -93 -work work {D:/DigitalLab26/lab3/Palindrome Detector.vhd}

vcom -93 -work work {D:/DigitalLab26/lab3/Testbench.vhd}
vcom -93 -work work {D:/DigitalLab26/lab3/DUT.vhd}
vcom -93 -work work {D:/DigitalLab26/lab3/Gates.vhd}

vsim -t 1ps -L altera -L lpm -L sgate -L altera_mf -L altera_lnsim -L fiftyfivenm -L rtl_work -L work -voptargs="+acc"  Testbench

add wave *
view structure
view signals
run -all
